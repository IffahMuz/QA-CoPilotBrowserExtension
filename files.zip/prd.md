# QA Copilot — Product Requirements & Task Breakdown (`prd.md`)

**Owner:** Iffah Muzaffar · **Consumed by:** the ralph loop (`ralph/run-loop.sh`) · **State:** [`progress.md`](./progress.md)

This document decomposes the QA Copilot build (`solution.md` → `blueprint.md`) into ordered, single-iteration tasks. Each task has a stable ID (`T##`) that mirrors a line in `progress.md`, a spec reference, the blueprint section that implements it, a done-when acceptance test, and a verification command. The ralph loop picks the first unchecked `T##`, implements exactly that task per `blueprint.md`, runs its verification, marks it done in `progress.md`, and commits.

**Rules for the loop:** implement one task per iteration; follow `blueprint.md` exactly; do not start a second task; if verification fails, fix until it passes or roll back. Tasks are ordered so each phase is shippable before the next begins (see `solution.md` → Delivery Plan).

---

## Phase S — Scaffolding

**T01 — Monorepo + docker-compose skeleton**
Spec §7.1.6/§7.1.8 · Blueprint: Project Structure, Configuration, SQL/Schema Reference (S1).
Create the `qa-copilot/` monorepo, `docker-compose.yml` (Postgres `pgvector/pgvector:pg16` + backend), and `db/init.sql` (schema + `CREATE EXTENSION vector`).
*Done when:* `docker compose up` brings Postgres up, `init.sql` applies, and `bug_reports` exists.
*Verify:* `docker compose up -d && docker compose exec postgres psql -U postgres -d qa_copilot -c '\d bug_reports'`

**T02 — Extension skeleton loads unpacked**
Spec §3.1 (MV3) · Blueprint: Project Structure, `manifest.json`.
Vite + `@crxjs/vite-plugin`, `manifest.json` (MV3, permissions incl. `debugger`/`tabCapture`/`offscreen`/`webNavigation`, `Ctrl+Shift+B` command, host `test-dms.targetdealer.com`).
*Done when:* `npm run build` produces a loadable unpacked extension; background worker registers.
*Verify:* `cd extension && npm run build`

**T03 — Ralph harness scaffold**
Blueprint: Ralph Loop Runner.
Create `ralph/run-loop.sh`, `ralph/iteration-prompt.md`, `ralph/verify.sh`, and seed `progress.md` from this PRD.
*Done when:* `run-loop.sh` dry-runs, detects unchecked tasks, and honors the `STOP` file + `MAX_ITERS`.
*Verify:* `bash -n ralph/run-loop.sh && bash -n ralph/verify.sh`

---

## Phase 0 — Thin end-to-end slice

**T04 — User-action collector (content script)**
Spec §4.2 (Module 2) · Blueprint: `content/UserActionCollector.ts`.
Capture clicks/double-clicks/keyboard/dropdowns/checkboxes/uploads/navigation/tab switches; emit **ordered, numbered** repro steps; **mask sensitive fields** at capture.
*Done when:* interacting with a page yields a numbered step list with password/token fields shown as masked.
*Verify:* `cd extension && npm run build`

**T05 — CDP debugger session**
Spec §4.3/§7.2 · Blueprint: `background/DebuggerSession.ts`.
Attach `chrome.debugger` 1.3; enable `Network`, `Runtime`, `Log`, **`Page`**; re-attach on navigation.
*Done when:* attaching to the target tab produces CDP events with no monkeypatching; survives a navigation.
*Verify:* `cd extension && npm run build`

**T06 — Console collector**
Spec §4.3 (Module 3) · Blueprint: `ConsoleNetworkCollector.ts` (console path).
Collect errors/warnings/uncaught exceptions/promise rejections with timestamp, stack, source file, line.
*Done when:* a thrown exception on the page appears as a console entry with a stack trace.
*Verify:* `cd extension && npm run build`

**T07 — Screenshot collector**
Spec §4.4 (Module 5) · Blueprint: `ScreenshotCollector.ts`.
Viewport via `captureVisibleTab`; full-page via CDP `Page.captureScreenshot` (`captureBeyondViewport`).
*Done when:* both a viewport and a full-page PNG are produced.
*Verify:* `cd extension && npm run build`

**T08 — Capture controller + trigger (slice exit)**
Spec §2 (slice), §C · Blueprint: `background/index.ts`, `CaptureController`.
`Ctrl+Shift+B` / popup freezes, snapshots the available collectors, and assembles a JSON evidence package locally.
*Done when:* one click / shortcut produces a complete local JSON evidence package (actions + screenshot + console).
*Verify:* `cd extension && npm run build`

---

## Phase 1 — Full collectors + redaction

**T09 — Session collector**
Spec §4.1 (Module 1) · Blueprint: `SessionCollector.ts`, `NavigationLog`, `DomProbe`.
URL, navigation history (webNavigation), browser/OS/resolution/viewport, time-on-page, logged-in user + current module where detectable.
*Verify:* `cd extension && npm run build`

**T10 — Environment collector**
Spec §4.1 (Module 7) · Blueprint: `EnvironmentCollector.ts`, `CookieProbe`.
Language, timezone, local/session storage, filtered cookies, feature flags, roles where available.
*Verify:* `cd extension && npm run build`

**T11 — Network collector → HAR**
Spec §4.3 (Module 4) · Blueprint: `ConsoleNetworkCollector.ts` (network path), `HarBuilder`.
Build a HAR from CDP; capture failed requests, headers, configurable payloads, status, timing; **highlight 400/401/403/404/409/422/500**.
*Verify:* `cd extension && npm run build`

**T12 — Offscreen rolling video buffer**
Spec §4.4/§7.1.4 (Module 6) · Blueprint: `offscreen/VideoBuffer.ts`, `CaptureController.ensureOffscreen`.
Offscreen document + `MediaRecorder`, bounded rolling window (3–5 min, default 180s); persist only the preceding window; transfer to worker (base64/ArrayBuffer, not raw Blob).
*Done when:* buffer stays bounded; capture yields only the trailing window.
*Verify:* `cd extension && npm run build`

**T13 — Redaction pipeline (client-side, non-negotiable)**
Spec §7.1.1/§7.3 · Blueprint: `redaction/RedactionPipeline.ts`.
Mask sensitive fields, filter cookies, strip configured payload bodies, scrub PII; emit `redaction_report`; **fail closed** (abort capture on throw).
*Done when:* a seeded known secret never appears in the assembled package; `redaction_report` lists what was removed.
*Verify:* `cd extension && npm run build` (plus a unit test asserting the seeded secret is absent)

---

## Phase 1b — Intake

**T14 — Evidence package + upload client**
Spec §3.3 · Blueprint: `shared/EvidencePackage.ts`, `shared/UploadClient.ts`.
Types for the package; multipart upload (inline JSON for session/env/actions/console/redaction_report; blobs for screenshot/video/HAR).
*Verify:* `cd extension && npm run build`

**T15 — Backend scaffold + data layer**
Spec §7.1.7 · Blueprint: `Program.cs`, `AppDbContext`, `BugReport`.
.NET 8 Web API, EF Core + Npgsql, `bug_reports` mapping with unique `capture_id`.
*Verify:* `cd backend && dotnet build -c Release`

**T16 — Evidence intake endpoint (idempotent)**
Spec §3.3, §7.1.3 · Blueprint: `EvidenceController`, `VolumeEvidenceStore` (S2).
`POST /api/evidence`: idempotent on `capture_id` (`ON CONFLICT`); save screenshot/video/HAR blobs **and** serialize `console.json` + `environment.json` to the volume so all five attachment types are available; status `RECEIVED`.
*Done when:* a second upload of the same `capture_id` returns `DUPLICATE` without a new row; the manifest lists all five artifacts.
*Verify:* `cd backend && dotnet build -c Release`

---

## Phase 2 — AI report + review

**T17 — LLM provider (Claude CLI)**
Spec §7.1.5/§7.3 (Module 8) · Blueprint: `ILlmProvider`, `ClaudeCliLlmProvider`, `PromptTemplate`.
Subprocess invocation behind the interface; versioned, grounded, JSON-only prompt that states gaps rather than hallucinating; record latency/spend per call.
*Done when:* a sample evidence package yields a structured JSON draft; latency is logged.
*Verify:* `cd backend && dotnet build -c Release`

**T18 — Generate endpoint**
Spec §4.5 (Module 8) · Blueprint: `BugReportDraft`, `ReportsController.Generate`.
`POST /api/reports/{id}/generate` → title, repro, expected/actual, console & failed-API summaries, environment summary, suspected module, suggested severity/priority; status `DRAFTED`; denormalize module/severity/priority.
*Verify:* `cd backend && dotnet build -c Release`

**T19 — Review-before-file UI**
Spec §4.5/§7.1.2, deliverable #3 · Blueprint: `popup/ReviewScreen.tsx`.
React + MUI screen: trigger generation, render every draft field editable, **File Bug** posts the edited draft.
*Done when:* the draft is fully editable and confirm calls `POST /file`.
*Verify:* `cd extension && npm run build`

---

## Phase 3 — Azure DevOps push

**T20 — Inspect TargetDMS Bug field schema (resolves open question)**
Spec §5, §7.2 · Blueprint: ADO Integration (note).
Inspect the live `TargetDMS` project: process template, required Bug fields, allowed Severity/Priority values, area/iteration paths. Record findings and adjust field paths in `AdoRestClient`.
*Done when:* the field map is confirmed and documented in the README/blueprint note.
*Verify:* manual — findings recorded in `progress.md` note.

**T21 — ADO REST client**
Spec §4.6/§7.1.3 (Module 9) · Blueprint: `IAdoClient`, `AdoRestClient`.
Upload each attachment; create the Bug via JSON Patch with fields + `AttachedFile` relations for all five attachments.
*Verify:* `cd backend && dotnet build -c Release`

**T22 — File endpoint (confirmed action, human-in-the-loop)**
Spec §4.6/§7.1.2/§7.1.3 · Blueprint: `ReportsController.File` (S4/S5).
`POST /api/reports/{id}/file`: persist `EDITED`; create the ADO bug with all five attachments in one action; `FILED` on success, `FAILED` + `error_details` on error.
*Done when:* one confirmed action produces a real, complete bug in TargetDMS with all attachments.
*Verify:* `cd backend && dotnet build -c Release`

---

## Phase 4 — Notify + harden

**T23 — Teams notifier (optional)**
Spec §4.6 (Module 10) · Blueprint: `INotifier`, `TeamsWebhookNotifier`.
Post module, severity, and assigned/responsible team to the incoming webhook on submit; best-effort, never reverses a successful filing.
*Verify:* `cd backend && dotnet build -c Release`

**T24 — README & Architecture Doc (deliverable #6)**
Spec §6 #6, §C · Blueprint: (cross-doc).
Install/run extension + backend locally, ADO/Teams credential config, collector/architecture map, redaction/privacy approach, limitations, next steps.
*Done when:* a reviewer can follow the README to install the extension, run the backend, and file a real bug.
*Verify:* manual review against §C checklist.

**T25 — End-to-end rehearsal + one-command bring-up**
Spec §C · Blueprint: Configuration.
Verify `docker compose up` (backend + Postgres) with Claude CLI on host; rehearse capture → generate → review → file against TargetDMS end-to-end.
*Done when:* the full acceptance checklist (§C) passes.
*Verify:* `./ralph/verify.sh` + manual §C walkthrough.

---

## Deferred — designed for, not in this build (spec §4.7)

Not tracked in `progress.md` (out of the committed scope; interfaces/schema leave room for them):

- Duplicate-bug detection (pgvector embedding search before filing).
- AI root-cause suggestions (advisory).
- Session timeline view.
- Full-page scroll-and-stitch screenshots (single full-page capture is the default).

---

## Reference

- [solution.md](./solution.md) · [blueprint.md](./blueprint.md) · [progress.md](./progress.md)
- Project Specification — QA Copilot Browser Extension (OPE AI Initiatives)
