# QA Copilot — Technical Implementation Guide

## Purpose

This document provides a complete technical implementation guide for **QA Copilot** — a two-part system plus an autonomous build harness:

- **`qa-copilot-extension`** — a TypeScript Manifest V3 browser extension that silently runs evidence collectors from app-open, freezes the session on capture, redacts secrets/PII client-side, and uploads an evidence package to the backend.
- **`qa-copilot-backend`** — a single .NET 8 (ASP.NET Core) service that receives the evidence package, invokes **Claude CLI** as a local subprocess behind an `ILlmProvider` interface to draft a structured bug report, and — on explicit human confirmation — files a developer-ready **Azure DevOps** bug into the **TargetDMS** project with all attachments and posts an optional **Microsoft Teams** notification.
- **`ralph/`** — the ralph loop runner that drives Claude Code against `prd.md` to build the system iteratively.

The extension talks to exactly three external surfaces, all reached from the background service worker or the backend:

- **Backend API** — receives the evidence package (`POST /api/evidence`) and drives generation and filing.
- **Claude CLI (host subprocess)** — invoked by the backend behind `ILlmProvider` for report generation.
- **PostgreSQL + local volume** — report metadata/index and evidence blobs; **Azure DevOps** and **Teams** are the two outbound integrations.

The whole system comes up locally via a single `docker-compose` command (backend + PostgreSQL), with Claude CLI running on the host. This document is intended to be consumed by a developer or copilot agent to plan and implement the system.

---

## Technology Stack

| Component | Technology |
| --- | --- |
| Extension | TypeScript, Manifest V3 (background service worker + content scripts + offscreen document) |
| Extension UI | React 18 + MUI (popup / review-before-file screen) |
| Console & Network capture | `chrome.debugger` (Chrome DevTools Protocol 1.3) |
| Media capture | `chrome.tabCapture` + `MediaRecorder` (rolling buffer); `chrome.tabs.captureVisibleTab` + CDP `Page.captureScreenshot` (screenshots) |
| Extension build | Vite + `@crxjs/vite-plugin` |
| Backend | .NET 8, ASP.NET Core Web API (controllers) |
| Data access | EF Core 8 + Npgsql (JSONB columns) |
| LLM provider | Claude CLI, invoked as a local subprocess behind `ILlmProvider` |
| Database | PostgreSQL 16 (Docker), `pgvector` extension on the same instance (future dedup) |
| Evidence storage | Local `docker-compose` volume, referenced from Postgres metadata |
| Integrations | Azure DevOps REST API (Work Items + attachments); Microsoft Teams incoming webhook |
| Orchestration | `docker-compose` (backend + Postgres); Claude CLI on host |
| Build harness | `ralph/run-loop.sh` driving Claude Code in headless/print mode against `prd.md` |

---

## Project Structure

Monorepo layout under `qa-copilot/`:

```
qa-copilot/
├── docker-compose.yml
├── db/
│   └── init.sql                         # schema + pgvector extension
├── extension/                            # TypeScript MV3
│   ├── manifest.json
│   ├── vite.config.ts
│   └── src/
│       ├── background/
│       │   ├── index.ts                  # service-worker entry (orchestrator)
│       │   ├── CaptureController.ts       # freeze → snapshot → redact → upload
│       │   └── DebuggerSession.ts         # chrome.debugger / CDP attach + events
│       ├── offscreen/
│       │   ├── offscreen.html
│       │   └── VideoBuffer.ts            # MediaRecorder rolling buffer
│       ├── content/
│       │   └── UserActionCollector.ts    # DOM events + field masking
│       ├── collectors/
│       │   ├── SessionCollector.ts
│       │   ├── EnvironmentCollector.ts
│       │   ├── ConsoleNetworkCollector.ts
│       │   └── ScreenshotCollector.ts
│       ├── redaction/
│       │   └── RedactionPipeline.ts      # non-negotiable, client-side
│       ├── shared/
│       │   ├── EvidencePackage.ts        # types
│       │   └── UploadClient.ts           # multipart upload to backend
│       └── popup/                         # React + MUI review-before-file UI
│           ├── main.tsx
│           └── ReviewScreen.tsx
├── backend/                              # .NET 8 ASP.NET Core
│   ├── Program.cs                        # host entry
│   ├── QaCopilot.Backend.csproj
│   ├── Dockerfile
│   ├── appsettings.json
│   ├── Controllers/
│   │   ├── EvidenceController.cs
│   │   └── ReportsController.cs
│   ├── Data/
│   │   ├── AppDbContext.cs
│   │   └── BugReport.cs                   # entity (bug_reports)
│   ├── Evidence/
│   │   ├── IEvidenceStore.cs
│   │   └── VolumeEvidenceStore.cs
│   ├── Llm/
│   │   ├── ILlmProvider.cs
│   │   ├── ClaudeCliLlmProvider.cs
│   │   ├── PromptTemplate.cs             # versioned prompt
│   │   └── BugReportDraft.cs             # structured output DTO
│   ├── Ado/
│   │   ├── IAdoClient.cs
│   │   └── AdoRestClient.cs
│   └── Teams/
│       ├── INotifier.cs
│       └── TeamsWebhookNotifier.cs
└── ralph/
    ├── run-loop.sh                       # the loop
    ├── iteration-prompt.md               # fixed per-iteration prompt
    ├── verify.sh                         # per-task verification gate
    └── progress.md                       # single source of truth for state
```

### Entry points

**`extension/manifest.json`** — declares MV3 permissions and the three execution contexts.

```json
{
  "manifest_version": 3,
  "name": "QA Copilot",
  "version": "0.1.0",
  "background": { "service_worker": "src/background/index.ts", "type": "module" },
  "content_scripts": [
    { "matches": ["https://test-dms.targetdealer.com/*"], "js": ["src/content/UserActionCollector.ts"], "run_at": "document_start" }
  ],
  "permissions": ["debugger", "tabCapture", "offscreen", "scripting", "storage", "activeTab", "tabs", "webNavigation"],
  "host_permissions": ["https://test-dms.targetdealer.com/*"],
  "commands": {
    "capture-bug": {
      "suggested_key": { "default": "Ctrl+Shift+B" },
      "description": "Capture Bug — freeze the session and assemble evidence"
    }
  },
  "action": { "default_popup": "src/popup/index.html" }
}
```

> The `service_worker` and `content_scripts` `.ts` paths above are rewritten to the compiled bundle by `@crxjs/vite-plugin` at build; raw TypeScript is not shipped.

**`backend/Program.cs`** — host entry (analogous to the template's application bootstrap class).

```csharp
using Microsoft.EntityFrameworkCore;
using QaCopilot.Backend.Data;
using QaCopilot.Backend.Evidence;
using QaCopilot.Backend.Llm;
using QaCopilot.Backend.Ado;
using QaCopilot.Backend.Teams;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseNpgsql(builder.Configuration.GetConnectionString("Postgres")));

builder.Services.AddSingleton<IEvidenceStore, VolumeEvidenceStore>();
builder.Services.AddSingleton<ILlmProvider, ClaudeCliLlmProvider>();
builder.Services.AddHttpClient<IAdoClient, AdoRestClient>();
builder.Services.AddHttpClient<INotifier, TeamsWebhookNotifier>();

var app = builder.Build();
app.MapControllers();
app.Run();
```

---

## Extension Core (background/ + offscreen/)

The background service worker is the orchestrator. Because MV3 evicts service workers aggressively, **all durable recording lives in the offscreen document**, and the worker holds no long-lived state — it wires collectors, owns the capture trigger, and coordinates the freeze. This is the cross-cutting concern the rest of the extension depends on.

### `background/index.ts` — orchestrator & trigger

```ts
import { CaptureController } from "./CaptureController";
import { DebuggerSession } from "./DebuggerSession";

const controller = new CaptureController();

// Arm collectors when the target tab is ready; ensure the offscreen doc exists.
chrome.runtime.onInstalled.addListener(() => controller.ensureOffscreen());

// Capture Bug: keyboard command or popup message.
chrome.commands.onCommand.addListener((cmd) => {
  if (cmd === "capture-bug") void controller.capture();
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "CAPTURE_BUG") {
    controller.capture().then((r) => sendResponse(r));
    return true; // async
  }
});

// Re-attach the debugger across navigations so CDP capture is continuous.
chrome.debugger.onDetach.addListener((source) => {
  if (source.tabId) DebuggerSession.reattach(source.tabId);
});
```

### `offscreen/VideoBuffer.ts` — rolling buffer via MediaRecorder

The buffer keeps only the trailing window (default 180s) by trimming timesliced chunks. Recording runs here, not in the worker, so eviction never interrupts it.

```ts
export class VideoBuffer {
  private recorder?: MediaRecorder;
  private chunks: { t: number; blob: Blob }[] = [];
  private windowMs = 180_000; // 3 min (configurable 3–5)

  async start(streamId: string) {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } } as any,
    });
    this.recorder = new MediaRecorder(stream, { mimeType: "video/webm;codecs=vp9" });
    this.recorder.ondataavailable = (e) => {
      const now = Date.now();
      this.chunks.push({ t: now, blob: e.data });
      // Trim anything older than the rolling window — bounded storage.
      const cutoff = now - this.windowMs;
      this.chunks = this.chunks.filter((c) => c.t >= cutoff);
    };
    this.recorder.start(1_000); // 1s timeslice
  }

  /** On capture: return only the preceding window as one Blob. */
  snapshot(): Blob {
    return new Blob(this.chunks.map((c) => c.blob), { type: "video/webm" });
  }
}
```

> **Transfer note:** `chrome.runtime.sendMessage` cannot structured-clone a `Blob` across contexts, so on capture the offscreen document either converts the snapshot to a base64 string / `ArrayBuffer` for the worker to reassemble, or uploads the `video` part to the backend directly. The worker never holds the raw `Blob` from the offscreen context.

The worker creates the offscreen document and hands it a tab-capture stream id:

```ts
// CaptureController.ensureOffscreen()
await chrome.offscreen.createDocument({
  url: "src/offscreen/offscreen.html",
  reasons: [chrome.offscreen.Reason.USER_MEDIA],
  justification: "Record the rolling video buffer for bug capture.",
});
const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
chrome.runtime.sendMessage({ type: "START_BUFFER", streamId });
```

### `background/DebuggerSession.ts` — CDP console + network

One `chrome.debugger` attachment feeds both the console and network collectors. HAR-ready network data and rich console events come from the same subscription — no `fetch`/`XHR`/`console` monkeypatching.

```ts
export class DebuggerSession {
  static async attach(tabId: number) {
    await chrome.debugger.attach({ tabId }, "1.3");
    await chrome.debugger.sendCommand({ tabId }, "Network.enable", {});
    await chrome.debugger.sendCommand({ tabId }, "Runtime.enable", {});
    await chrome.debugger.sendCommand({ tabId }, "Log.enable", {});
    await chrome.debugger.sendCommand({ tabId }, "Page.enable", {}); // required for Page.captureScreenshot
    chrome.debugger.onEvent.addListener(DebuggerSession.onEvent);
  }

  static reattach(tabId: number) { void DebuggerSession.attach(tabId); }

  private static onEvent(source: chrome.debugger.Debuggee, method: string, params: any) {
    switch (method) {
      case "Network.requestWillBeSent":
      case "Network.responseReceived":
      case "Network.loadingFinished":
        ConsoleNetworkCollector.onNetwork(method, params); break;
      case "Runtime.exceptionThrown":
      case "Runtime.consoleAPICalled":
      case "Log.entryAdded":
        ConsoleNetworkCollector.onConsole(method, params); break;
    }
  }
}
```

---

## Collector Layer (collectors/ + content/)

Each collector is a small class exposing `snapshot()`, returning the slice of the evidence package it owns. The `CaptureController` calls all of them at freeze time. This layer is analogous to the template's entity layer — one type per data concern.

### `SessionCollector.ts`

```ts
export class SessionCollector {
  snapshot(tab: chrome.tabs.Tab) {
    return {
      url: tab.url,
      navigationHistory: NavigationLog.entries(),      // maintained from webNavigation
      browser: navigator.userAgent,
      os: navigator.platform,
      resolution: `${screen.width}x${screen.height}`,
      viewport: `${window.innerWidth}x${window.innerHeight}`,
      timeOnPageMs: Date.now() - NavigationLog.landedAt(),
      loggedInUser: DomProbe.detectUser(),              // best-effort, may be null
      currentModule: DomProbe.detectModule(),
    };
  }
}
```

### `EnvironmentCollector.ts`

Captures language, timezone, storage, filtered cookies, feature flags, and roles where available. Storage/cookies are handed straight into the redaction pipeline.

```ts
export class EnvironmentCollector {
  snapshot() {
    return {
      language: navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      localStorage: { ...localStorage },        // redacted downstream
      sessionStorage: { ...sessionStorage },     // redacted downstream
      cookies: CookieProbe.filtered(),           // secure/session cookies excluded
      featureFlags: DomProbe.featureFlags(),
      roles: DomProbe.userRoles(),
    };
  }
}
```

### `ConsoleNetworkCollector.ts`

Accumulates CDP events into console entries and a HAR document; flags failed requests.

```ts
export class ConsoleNetworkCollector {
  private static console: ConsoleEntry[] = [];
  private static har = new HarBuilder();
  private static readonly HIGHLIGHT = [400, 401, 403, 404, 409, 422, 500];

  static onConsole(method: string, p: any) {
    this.console.push({
      level: p.type ?? p.entry?.level ?? "error",
      text: p.exceptionDetails?.text ?? p.args?.map((a: any) => a.value).join(" ") ?? p.entry?.text,
      timestamp: Date.now(),
      stack: p.exceptionDetails?.stackTrace,
      source: p.entry?.url,
      line: p.entry?.lineNumber,
    });
  }

  static onNetwork(method: string, p: any) { this.har.consume(method, p); }

  snapshot() {
    const har = this.har.build();
    har.log.entries.forEach((e: any) => {
      e._failed = e.response && ConsoleNetworkCollector.HIGHLIGHT.includes(e.response.status);
    });
    return { console: ConsoleNetworkCollector.console, network: har };
  }
}
```

### `ScreenshotCollector.ts`

Viewport via `captureVisibleTab`; full page via CDP `Page.captureScreenshot` with `captureBeyondViewport` (avoids scroll-and-stitch).

```ts
export class ScreenshotCollector {
  async snapshot(tabId: number) {
    const viewport = await chrome.tabs.captureVisibleTab({ format: "png" });
    const full = await chrome.debugger.sendCommand({ tabId }, "Page.captureScreenshot", {
      captureBeyondViewport: true, fromSurface: true, format: "png",
    }) as { data: string };
    return { viewportPng: viewport, fullPagePng: `data:image/png;base64,${full.data}` };
  }
}
```

### `content/UserActionCollector.ts`

Runs in the page. Emits ordered, numbered, human-readable events; masks sensitive fields **at the point of capture**.

```ts
const SENSITIVE = /pass|token|secret|ssn|card|cvv|pin/i;
const steps: string[] = [];

function label(el: HTMLElement): string {
  return el.getAttribute("aria-label") ?? el.getAttribute("name") ?? el.textContent?.trim().slice(0, 40) ?? el.tagName;
}

document.addEventListener("click", (e) => {
  const el = e.target as HTMLElement;
  steps.push(`${steps.length + 1}. Click "${label(el)}"`);
}, true);

document.addEventListener("change", (e) => {
  const el = e.target as HTMLInputElement;
  const value = SENSITIVE.test(el.name + el.type) ? "••••• (masked)" : el.value?.slice(0, 40);
  steps.push(`${steps.length + 1}. Set "${label(el)}" = ${value}`);
}, true);

chrome.runtime.onMessage.addListener((msg, _s, send) => {
  if (msg.type === "SNAPSHOT_ACTIONS") send({ steps });
});
```

---

## Redaction Pipeline (redaction/) — non-negotiable

Runs in the background worker after snapshotting and **before** the package leaves the browser or reaches Claude CLI. It masks fields, filters cookies, strips configured payload bodies, and emits a `redaction_report` (what was removed, never the values). If it throws, capture aborts (fail closed).

```ts
export interface RedactionReport { maskedFields: string[]; strippedBodies: number; removedCookies: string[]; }

export class RedactionPipeline {
  private static SECRET_KEY = /pass|token|secret|key|auth|ssn|card|cvv/i;
  private static PII = /\b[\w.+-]+@[\w-]+\.[\w.-]+\b|\b\d{3}-\d{2}-\d{4}\b/g;

  run(pkg: EvidencePackage): { pkg: EvidencePackage; report: RedactionReport } {
    const report: RedactionReport = { maskedFields: [], strippedBodies: 0, removedCookies: [] };

    // Storage: drop secret-looking keys.
    for (const store of [pkg.environment.localStorage, pkg.environment.sessionStorage]) {
      for (const k of Object.keys(store)) {
        if (RedactionPipeline.SECRET_KEY.test(k)) { delete store[k]; report.maskedFields.push(k); }
      }
    }
    // Cookies already filtered upstream; record what was dropped.
    report.removedCookies = pkg.environment.cookies.filter(c => c.httpOnly || c.secure).map(c => c.name);

    // Network: strip request/response bodies per policy; scrub PII from URLs/headers.
    for (const entry of pkg.network.log.entries) {
      if (this.shouldStripBody(entry)) { delete entry.request.postData; delete entry.response.content.text; report.strippedBodies++; }
      entry.request.url = entry.request.url.replace(RedactionPipeline.PII, "[redacted]");
    }
    pkg.redaction_report = report;
    return { pkg, report };
  }

  private shouldStripBody(entry: any): boolean {
    // Default policy: strip bodies on auth/token endpoints; keep 4xx/5xx diagnostic bodies.
    return /auth|login|token/i.test(entry.request.url);
  }
}
```

---

## Capture & Upload (shared/)

### `shared/EvidencePackage.ts` — the contract

```ts
export interface EvidencePackage {
  capture_id: string;          // UUID, client idempotency key
  captured_at: string;         // ISO-8601
  session: SessionInfo;
  environment: EnvironmentInfo;
  actions: string[];           // numbered repro steps
  console: ConsoleEntry[];
  network: HarDocument;
  screenshot: { viewportPng: string; fullPagePng: string };
  video: Blob;                 // trimmed buffer window
  redaction_report?: RedactionReport;
}
```

### `shared/UploadClient.ts` — multipart intake

Inline JSON (session/environment/actions/console/redaction_report) travels in one part; `screenshot`, `video`, and the HAR go as blobs.

```ts
export class UploadClient {
  constructor(private baseUrl: string) {}

  async upload(pkg: EvidencePackage): Promise<{ report_id: number; status: string }> {
    const form = new FormData();
    const { screenshot, video, network, ...inline } = pkg;
    form.append("package", new Blob([JSON.stringify({ ...inline, screenshot: "ref", video: "ref" })], { type: "application/json" }));
    form.append("har", new Blob([JSON.stringify(network)], { type: "application/json" }), "network.har");
    form.append("screenshot", await (await fetch(screenshot.fullPagePng)).blob(), "screenshot.png");
    form.append("video", video, "video.webm");
    const res = await fetch(`${this.baseUrl}/api/evidence`, { method: "POST", body: form });
    return res.json();
  }
}
```

---

## Extension — Review UI (popup/)

The human-in-the-loop screen (spec §4.5, §7.1.2, deliverable #3). After upload it triggers generation, renders every draft field as an editable MUI control, and on confirm posts the edited draft to `POST /api/reports/{id}/file`. Nothing is filed until the user clicks **File Bug**.

### `popup/ReviewScreen.tsx`

```tsx
import { useEffect, useState } from "react";
import { Box, Button, TextField, MenuItem, Stack, Typography } from "@mui/material";

type Draft = {
  title: string; reproSteps: string[]; expected: string; actual: string;
  consoleErrorSummary: string; failedApiSummary: string; environmentSummary: string;
  suspectedModule: string; severity: string; priority: string; assignedTeam?: string;
};

export function ReviewScreen({ reportId, apiBase }: { reportId: number; apiBase: string }) {
  const [draft, setDraft] = useState<Draft | null>(null);
  const [filing, setFiling] = useState(false);
  const [filed, setFiled] = useState<{ id: number; url: string } | null>(null);

  // Kick off generation, then load the editable draft.
  useEffect(() => {
    fetch(`${apiBase}/api/reports/${reportId}/generate`, { method: "POST" })
      .then((r) => r.json()).then(setDraft);
  }, [reportId]);

  const set = (k: keyof Draft) => (e: any) => setDraft({ ...draft!, [k]: e.target.value });

  async function fileBug() {
    setFiling(true);
    const res = await fetch(`${apiBase}/api/reports/${reportId}/file`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(draft),
    });
    const body = await res.json();
    if (res.ok) setFiled({ id: body.ado_work_item_id, url: body.url });
    setFiling(false);
  }

  if (!draft) return <Typography>Generating report…</Typography>;
  if (filed) return <Typography>Filed ADO bug #{filed.id} — <a href={filed.url}>open</a></Typography>;

  return (
    <Box sx={{ p: 2, width: 480 }}>
      <Stack spacing={1.5}>
        <TextField label="Title" value={draft.title} onChange={set("title")} fullWidth />
        <TextField label="Repro steps" value={draft.reproSteps.join("\n")}
                   onChange={(e) => setDraft({ ...draft, reproSteps: e.target.value.split("\n") })}
                   multiline minRows={4} fullWidth />
        <TextField label="Expected" value={draft.expected} onChange={set("expected")} multiline fullWidth />
        <TextField label="Actual" value={draft.actual} onChange={set("actual")} multiline fullWidth />
        <TextField label="Console summary" value={draft.consoleErrorSummary} onChange={set("consoleErrorSummary")} multiline fullWidth />
        <TextField label="Failed API summary" value={draft.failedApiSummary} onChange={set("failedApiSummary")} multiline fullWidth />
        <TextField label="Environment summary" value={draft.environmentSummary} onChange={set("environmentSummary")} multiline fullWidth />
        <TextField label="Suspected module" value={draft.suspectedModule} onChange={set("suspectedModule")} fullWidth />
        <TextField select label="Severity" value={draft.severity} onChange={set("severity")}>
          {["Low", "Medium", "High", "Critical"].map((s) => <MenuItem key={s} value={s}>{s}</MenuItem>)}
        </TextField>
        <TextField select label="Priority" value={draft.priority} onChange={set("priority")}>
          {["Low", "Medium", "High"].map((p) => <MenuItem key={p} value={p}>{p}</MenuItem>)}
        </TextField>
        <TextField label="Assigned team" value={draft.assignedTeam ?? ""} onChange={set("assignedTeam")} fullWidth />
        <Button variant="contained" disabled={filing} onClick={fileBug}>
          {filing ? "Filing…" : "File Bug"}
        </Button>
      </Stack>
    </Box>
  );
}
```

Every AI-suggested field is editable before filing, and the draft's own evidence summaries (console, failed-API, environment) are shown alongside so the reviewer can trust or reject each recommendation.

---

## Backend — Data Layer (Data/)

### `BugReport.cs` — entity (`bug_reports`)

Maps to the `bug_reports` table. `draft_report` / `edited_report` / `evidence_manifest` are JSONB. The top-level `Module`/`Severity`/`Priority` columns are denormalized copies of the confirmed report for SQL querying; the JSON is the source of truth.

```csharp
using System.ComponentModel.DataAnnotations.Schema;

namespace QaCopilot.Backend.Data;

[Table("bug_reports")]
public class BugReport
{
    [Column("id")] public long Id { get; set; }
    [Column("capture_id")] public Guid CaptureId { get; set; }         // UNIQUE
    [Column("created_at")] public DateTimeOffset CreatedAt { get; set; }
    [Column("updated_at")] public DateTimeOffset UpdatedAt { get; set; }
    [Column("status")] public string Status { get; set; } = "RECEIVED"; // RECEIVED/DRAFTED/EDITED/FILED/FAILED
    [Column("target_url")] public string? TargetUrl { get; set; }
    [Column("module")] public string? Module { get; set; }
    [Column("severity")] public string? Severity { get; set; }
    [Column("priority")] public string? Priority { get; set; }
    [Column("draft_report", TypeName = "jsonb")] public string? DraftReport { get; set; }
    [Column("edited_report", TypeName = "jsonb")] public string? EditedReport { get; set; }
    [Column("ado_work_item_id")] public long? AdoWorkItemId { get; set; }
    [Column("evidence_manifest", TypeName = "jsonb")] public string? EvidenceManifest { get; set; }
    [Column("error_details")] public string? ErrorDetails { get; set; }
}
```

### `AppDbContext.cs`

```csharp
using Microsoft.EntityFrameworkCore;

namespace QaCopilot.Backend.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}
    public DbSet<BugReport> BugReports => Set<BugReport>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<BugReport>().HasIndex(r => r.CaptureId).IsUnique(); // idempotent intake
    }
}
```

### `IEvidenceStore` / `VolumeEvidenceStore`

Writes blobs under a per-capture directory on the docker-compose volume; returns the manifest referenced from Postgres and the ADO ticket.

```csharp
public interface IEvidenceStore
{
    Task<EvidenceManifest> SaveAsync(Guid captureId, IFormFileCollection files);
    Task WriteJsonAsync(Guid captureId, string fileName, object payload, EvidenceManifest manifest);
    Task<Stream> OpenAsync(string path);
}

public class VolumeEvidenceStore : IEvidenceStore
{
    private readonly string _root; // e.g. /evidence (mounted volume)
    public VolumeEvidenceStore(IConfiguration cfg) => _root = cfg["Evidence:Root"] ?? "/evidence";

    public async Task<EvidenceManifest> SaveAsync(Guid captureId, IFormFileCollection files)
    {
        var dir = Path.Combine(_root, captureId.ToString());
        Directory.CreateDirectory(dir);
        var manifest = new EvidenceManifest();
        foreach (var f in files)
        {
            var path = Path.Combine(dir, f.FileName);
            await using var fs = File.Create(path);
            await f.CopyToAsync(fs);
            manifest.Add(f.Name, path);
        }
        return manifest;
    }
    public async Task WriteJsonAsync(Guid captureId, string fileName, object payload, EvidenceManifest manifest)
    {
        var dir = Path.Combine(_root, captureId.ToString());
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, fileName);
        await File.WriteAllTextAsync(path, JsonSerializer.Serialize(payload));
        manifest.Add(Path.GetFileNameWithoutExtension(fileName), path);
    }

    public Task<Stream> OpenAsync(string path) => Task.FromResult<Stream>(File.OpenRead(path));
}
```

---

## Backend — API Layer (Controllers/)

Three endpoints implement the pipeline. `File` is the human-in-the-loop confirm gate — nothing is filed or notified without it.

### `EvidenceController.cs` — intake (idempotent)

```csharp
[ApiController]
[Route("api/evidence")]
public class EvidenceController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IEvidenceStore _store;
    public EvidenceController(AppDbContext db, IEvidenceStore store) { _db = db; _store = store; }

    [HttpPost]
    public async Task<IActionResult> Intake([FromForm] IFormFile package)
    {
        var pkg = await JsonSerializer.DeserializeAsync<EvidencePackage>(package.OpenReadStream());
        var existing = await _db.BugReports.FirstOrDefaultAsync(r => r.CaptureId == pkg!.CaptureId);
        if (existing is not null)
            return Ok(new { report_id = existing.Id, capture_id = existing.CaptureId, status = "DUPLICATE" });

        var manifest = await _store.SaveAsync(pkg!.CaptureId, Request.Form.Files);
        // Console + environment travel inline in the JSON package; serialize them to the volume so all
        // five attachment types (screenshot, video, HAR, console logs, environment) reach the ADO bug (§7.1.3).
        await _store.WriteJsonAsync(pkg.CaptureId, "console.json", pkg.Console, manifest);
        await _store.WriteJsonAsync(pkg.CaptureId, "environment.json", pkg.Environment, manifest);
        var report = new BugReport
        {
            CaptureId = pkg.CaptureId, Status = "RECEIVED",
            TargetUrl = pkg.Session.Url, CreatedAt = DateTimeOffset.UtcNow, UpdatedAt = DateTimeOffset.UtcNow,
            EvidenceManifest = JsonSerializer.Serialize(manifest),
        };
        _db.BugReports.Add(report);
        await _db.SaveChangesAsync();
        return Ok(new { report_id = report.Id, capture_id = report.CaptureId, status = "RECEIVED" });
    }
}
```

> `DUPLICATE` is a response-only outcome flag — it is never written to `status`; a repeated `capture_id` leaves the existing row at its current state.

### `ReportsController.cs` — generate & file

```csharp
[ApiController]
[Route("api/reports")]
public class ReportsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IEvidenceStore _store;
    private readonly ILlmProvider _llm;
    private readonly IAdoClient _ado;
    private readonly INotifier _notifier;

    public ReportsController(AppDbContext db, IEvidenceStore store, ILlmProvider llm, IAdoClient ado, INotifier notifier)
        { _db = db; _store = store; _llm = llm; _ado = ado; _notifier = notifier; }

    [HttpPost("{id}/generate")]
    public async Task<IActionResult> Generate(long id)
    {
        var report = await _db.BugReports.FindAsync(id) ?? throw new KeyNotFoundException();
        var evidence = await EvidenceLoader.LoadAsync(_store, report); // redacted package already
        var draft = await _llm.GenerateAsync(evidence);                 // grounded, structured
        report.DraftReport = JsonSerializer.Serialize(draft);
        report.Module = draft.SuspectedModule; report.Severity = draft.Severity; report.Priority = draft.Priority;
        report.Status = "DRAFTED"; report.UpdatedAt = DateTimeOffset.UtcNow;
        await _db.SaveChangesAsync();
        return Ok(draft);
    }

    [HttpPost("{id}/file")]
    public async Task<IActionResult> File(long id, [FromBody] BugReportDraft edited)
    {
        var report = await _db.BugReports.FindAsync(id) ?? throw new KeyNotFoundException();
        // Human-in-the-loop: persist the approved edit as EDITED before any outbound call.
        report.EditedReport = JsonSerializer.Serialize(edited);
        report.Module = edited.SuspectedModule; report.Severity = edited.Severity; report.Priority = edited.Priority;
        report.Status = "EDITED"; report.UpdatedAt = DateTimeOffset.UtcNow;
        await _db.SaveChangesAsync();

        try
        {
            var manifest = JsonSerializer.Deserialize<EvidenceManifest>(report.EvidenceManifest!)!;
            var workItemId = await _ado.CreateBugWithAttachmentsAsync(edited, manifest, _store);
            report.AdoWorkItemId = workItemId; report.Status = "FILED"; report.UpdatedAt = DateTimeOffset.UtcNow;
            await _db.SaveChangesAsync();

            await _notifier.NotifyAsync(edited.SuspectedModule, edited.Severity, edited.AssignedTeam); // optional
            return Ok(new { ado_work_item_id = workItemId, url = _ado.WorkItemUrl(workItemId), status = "FILED" });
        }
        catch (Exception ex)
        {
            report.Status = "FAILED"; report.ErrorDetails = ex.Message; await _db.SaveChangesAsync();
            return StatusCode(502, new { status = "FAILED", error = ex.Message });
        }
    }
}
```

---

## Backend — LLM Provider (Llm/)

Analogous to the template's service interface → concrete implementation. Report generation is one grounded call behind `ILlmProvider`; the Claude CLI subprocess is the only implementation for the demo.

### `ILlmProvider.cs`

```csharp
public interface ILlmProvider
{
    Task<BugReportDraft> GenerateAsync(EvidencePackage evidence, CancellationToken ct = default);
}
```

### `ClaudeCliLlmProvider.cs`

Invokes `claude` as a subprocess, pipes the grounded prompt on stdin, and parses JSON from stdout. No cloud API keys; no vendor SDK.

```csharp
public class ClaudeCliLlmProvider : ILlmProvider
{
    private readonly IConfiguration _cfg;
    private readonly ILogger<ClaudeCliLlmProvider> _log;
    public ClaudeCliLlmProvider(IConfiguration cfg, ILogger<ClaudeCliLlmProvider> log) { _cfg = cfg; _log = log; }

    public async Task<BugReportDraft> GenerateAsync(EvidencePackage evidence, CancellationToken ct = default)
    {
        var prompt = PromptTemplate.Build(evidence); // versioned; instructs "JSON only", grounded-in-evidence

        var psi = new ProcessStartInfo
        {
            FileName = _cfg["Llm:ClaudeCliPath"] ?? "claude",
            RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false,
        };
        psi.ArgumentList.Add("-p");                 // headless / print mode
        psi.ArgumentList.Add("--output-format"); psi.ArgumentList.Add("text");

        var sw = Stopwatch.StartNew();
        using var proc = Process.Start(psi)!;
        await proc.StandardInput.WriteAsync(prompt); proc.StandardInput.Close();
        var stdout = await proc.StandardOutput.ReadToEndAsync(ct);
        await proc.WaitForExitAsync(ct);
        sw.Stop();
        _log.LogInformation("Claude CLI generate: {ms} ms, exit={code}, prompt_chars={n}",
            sw.ElapsedMilliseconds, proc.ExitCode, prompt.Length); // latency/spend per §7.3
        if (proc.ExitCode != 0) throw new LlmException(await proc.StandardError.ReadToEndAsync(ct));

        var json = JsonExtractor.FirstObject(stdout); // tolerate any wrapper text
        return JsonSerializer.Deserialize<BugReportDraft>(json)
            ?? throw new LlmException("Empty draft");
    }
}
```

> **Claude CLI flags** (`-p`, `--output-format`) should be confirmed against the current Claude Code docs — see References. Prompt and invocation contract are versioned artifacts in `PromptTemplate.cs`.

### `BugReportDraft.cs` — structured output

```csharp
public record BugReportDraft(
    string Title,
    string[] ReproSteps,
    string Expected,
    string Actual,
    string ConsoleErrorSummary,
    string FailedApiSummary,
    string EnvironmentSummary,
    string SuspectedModule,
    string Severity,
    string Priority,
    string? AssignedTeam
);
```

### `PromptTemplate.cs` — versioned, grounded prompt

The prompt is a versioned artifact. It supplies only the redacted evidence as context and forbids answering from parametric memory.

```csharp
public static class PromptTemplate
{
    public const string Version = "v1";

    public static string Build(EvidencePackage e) => $$"""
        You are a QA bug-report generator. Use ONLY the evidence below — do not use prior
        knowledge. If a required detail is missing from the evidence, say so in that field
        rather than inventing it. Respond with a single JSON object matching this shape:
        {"title","reproSteps":[],"expected","actual","consoleErrorSummary","failedApiSummary",
         "environmentSummary","suspectedModule","severity","priority","assignedTeam"}

        EVIDENCE (redacted):
        session: {{JsonSerializer.Serialize(e.Session)}}
        actions (numbered repro): {{JsonSerializer.Serialize(e.Actions)}}
        console: {{JsonSerializer.Serialize(e.Console)}}
        failed requests: {{JsonSerializer.Serialize(FailedOnly(e.Network))}}
        environment: {{JsonSerializer.Serialize(e.Environment)}}
        """;
}
```

### Adding a new LLM provider

To swap in a hosted model later: implement `ILlmProvider`, register it in `Program.cs` in place of `ClaudeCliLlmProvider`. No controller or feature code changes — the interface is the only touch point.

---

## Backend — ADO Integration (Ado/)

Analogous to the template's REST client. Creates a Bug work item in **TargetDMS** and uploads all attachments in one confirmed action.

### `IAdoClient.cs`

```csharp
public interface IAdoClient
{
    Task<long> CreateBugWithAttachmentsAsync(BugReportDraft report, EvidenceManifest manifest, IEvidenceStore store);
    string WorkItemUrl(long id);
}
```

### `AdoRestClient.cs`

```csharp
public class AdoRestClient : IAdoClient
{
    private readonly HttpClient _http;
    private readonly string _org, _project;

    public AdoRestClient(HttpClient http, IConfiguration cfg)
    {
        _http = http;
        _org = cfg["Ado:OrgUrl"]!;      // https://constellationdealer.visualstudio.com
        _project = cfg["Ado:Project"]!; // TargetDMS
        var pat = cfg["Ado:Pat"]!;      // PLACEHOLDER — injected via env at runtime
        var basic = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{pat}"));
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", basic);
    }

    public async Task<long> CreateBugWithAttachmentsAsync(BugReportDraft r, EvidenceManifest manifest, IEvidenceStore store)
    {
        // 1) Upload each attachment, collect its URL.
        var refs = new List<(string name, string url)>();
        foreach (var (name, path) in manifest.Files)
        {
            await using var s = await store.OpenAsync(path);
            var up = await _http.PostAsync(
                $"{_org}/{_project}/_apis/wit/attachments?fileName={Uri.EscapeDataString(name)}&api-version=7.0",
                new StreamContent(s));
            up.EnsureSuccessStatusCode();
            var url = (await up.Content.ReadFromJsonAsync<AdoAttachment>())!.Url;
            refs.Add((name, url));
        }

        // 2) Create the Bug with fields + attachment relations (JSON Patch).
        var patch = new List<object>
        {
            new { op = "add", path = "/fields/System.Title", value = r.Title },
            new { op = "add", path = "/fields/Microsoft.VSTS.TCM.ReproSteps", value = string.Join("<br/>", r.ReproSteps) },
            new { op = "add", path = "/fields/Microsoft.VSTS.Common.Severity", value = r.Severity },
            new { op = "add", path = "/fields/Microsoft.VSTS.Common.Priority", value = MapPriority(r.Priority) },
            new { op = "add", path = "/fields/System.Description",
                  value = $"<b>Expected</b>: {r.Expected}<br/><b>Actual</b>: {r.Actual}<br/>" +
                          $"<b>Console</b>: {r.ConsoleErrorSummary}<br/><b>Failed APIs</b>: {r.FailedApiSummary}<br/>" +
                          $"<b>Environment</b>: {r.EnvironmentSummary}<br/><b>Module</b>: {r.SuspectedModule}" },
        };
        patch.AddRange(refs.Select(a => (object)new {
            op = "add", path = "/relations/-",
            value = new { rel = "AttachedFile", url = a.url, attributes = new { comment = a.name } }
        }));

        var content = new StringContent(JsonSerializer.Serialize(patch), Encoding.UTF8, "application/json-patch+json");
        var res = await _http.PostAsync($"{_org}/{_project}/_apis/wit/workitems/$Bug?api-version=7.0", content);
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<AdoWorkItem>())!.Id;
    }

    public string WorkItemUrl(long id) => $"{_org}/{_project}/_workitems/edit/{id}";
    private static int MapPriority(string p) => p.ToLower() switch { "high" => 1, "medium" => 2, _ => 3 };
}
```

> The exact **field schema** (process template, required fields, allowed Severity/Priority values, area/iteration paths) will be confirmed by inspecting the live TargetDMS project — see the Open Question carried from `solution.md`. The field paths above are the ADO defaults and may be adjusted after inspection.

---

## Backend — Teams Notifier (Teams/)

Optional, behind `INotifier`, posting to a single incoming webhook (a deliberate demo substitute for Microsoft Graph). Failure is best-effort and never reverses a successful ADO filing.

### `INotifier.cs`

```csharp
public interface INotifier
{
    Task NotifyAsync(string module, string severity, string? assignedTeam, CancellationToken ct = default);
}
```

### `TeamsWebhookNotifier.cs`

```csharp
public class TeamsWebhookNotifier : INotifier
{
    private readonly HttpClient _http;
    private readonly string? _webhook;
    public TeamsWebhookNotifier(HttpClient http, IConfiguration cfg) { _http = http; _webhook = cfg["Teams:WebhookUrl"]; }

    public async Task NotifyAsync(string module, string severity, string? assignedTeam, CancellationToken ct = default)
    {
        if (string.IsNullOrEmpty(_webhook)) return; // optional — no-op if unconfigured
        var card = new
        {
            text = $"🐞 New bug submitted — module **{module}**, severity **{severity}**" +
                   (assignedTeam is null ? "" : $", team **{assignedTeam}**")
        };
        try { await _http.PostAsJsonAsync(_webhook, card, ct); }
        catch (Exception) { /* logged, swallowed — best-effort */ }
    }
}
```

---

## Ralph Loop Runner (ralph/)

The build harness. `run-loop.sh` invokes **Claude Code in headless/print mode** each iteration against the fixed prompt, runs the verification gate, and commits per iteration. `progress.md` is the single source of truth for state.

### `ralph/run-loop.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

MAX_ITERS="${MAX_ITERS:-60}"
i=0

while (( i < MAX_ITERS )); do
  [[ -f STOP ]] && { echo "STOP sentinel present — halting."; break; }

  # Done when no unchecked tasks remain in progress.md.
  if ! grep -q '^\- \[ \]' progress.md; then
    echo "All tasks complete."; break
  fi

  echo "=== Ralph iteration $i ==="
  # Headless Claude Code against the fixed iteration prompt.
  claude -p --dangerously-skip-permissions "$(cat ralph/iteration-prompt.md)" || true

  # Per-task verification gate: build must pass before the work counts.
  if ./ralph/verify.sh; then
    git add -A && git commit -m "ralph: iteration $i" || true
  else
    echo "Verification failed — rolling back this iteration."
    git reset --hard HEAD
  fi
  (( i++ )) || true
done
```

### `ralph/iteration-prompt.md` (fixed)

```
You are building QA Copilot per prd.md. State lives in progress.md.

1. Read solution.md, blueprint.md, prd.md, and progress.md.
2. Pick the FIRST unchecked task ("- [ ]") in progress.md.
3. Implement ONLY that task, following blueprint.md exactly.
4. Run ./ralph/verify.sh. If it fails, fix until it passes.
5. Mark the task "- [x]" in progress.md with a one-line note.
6. Do not start another task. Stop.
```

### `ralph/verify.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
( cd extension && npm run build )      # extension compiles
( cd backend   && dotnet build -c Release )  # backend compiles
# task-specific checks appended here as the build grows (e.g. dotnet test)
```

### `progress.md` schema

A flat checklist mirroring `prd.md` task IDs; one line per task, `- [ ]` / `- [x]`, with an optional trailing note. Example:

```
- [x] T01 Scaffold docker-compose (backend + Postgres) — comes up clean
- [ ] T02 Extension skeleton loads unpacked in Chrome
- [ ] T03 UserActionCollector emits numbered repro steps
```

Guardrails: git commit per iteration (rollback = one `reset`), the verification gate (no advance on broken code), `MAX_ITERS` + `STOP` file (no runaway), and `progress.md` as resumable state.

> **Claude Code invocation** (`claude -p`, `--dangerously-skip-permissions`) should be confirmed against the current Claude Code docs — see References.

---

## Support Types

Small helper types referenced above, implemented alongside their owners (kept out of the main listings for brevity):

- **Extension:** `NavigationLog` (webNavigation-fed history), `DomProbe` (user/module/flags/roles detection), `CookieProbe` (secure/httpOnly filtering), `HarBuilder` (CDP events → HAR), and the `EvidencePackage` sub-types (`SessionInfo`, `EnvironmentInfo`, `ConsoleEntry`, `HarDocument`).
- **Backend:** `EvidenceManifest` (name→path map with `Add`/`Files`), `EvidenceLoader` (rebuilds the redacted package from the volume), `JsonExtractor.FirstObject` (tolerant JSON slice from CLI stdout), `AdoAttachment`/`AdoWorkItem` (REST DTOs), and `LlmException`.

---

## Configuration

### `backend/appsettings.json`

```json
{
  "ConnectionStrings": { "Postgres": "Host=postgres;Port=5432;Database=qa_copilot;Username=postgres;Password=postgres" },
  "Evidence": { "Root": "/evidence" },
  "Llm": { "ClaudeCliPath": "claude" },
  "Ado": {
    "OrgUrl": "https://constellationdealer.visualstudio.com",
    "Project": "TargetDMS",
    "Pat": "${ADO_PAT}"
  },
  "Teams": { "WebhookUrl": "${TEAMS_WEBHOOK_URL}" }
}
```

> `Ado:Pat` is a **placeholder** injected from the environment at runtime — the backend needs its own PAT with Work Items (read/write) scope. No secrets are committed.

### `docker-compose.yml`

The whole system comes up with one command; Claude CLI runs on the host and is reached by the backend via the mounted host path.

```yaml
services:
  postgres:
    image: pgvector/pgvector:pg16
    environment: { POSTGRES_DB: qa_copilot, POSTGRES_PASSWORD: postgres }
    ports: ["5432:5432"]
    volumes: ["./db/init.sql:/docker-entrypoint-initdb.d/init.sql", "pgdata:/var/lib/postgresql/data"]

  backend:
    build: ./backend
    depends_on: [postgres]
    environment:
      ADO_PAT: ${ADO_PAT}
      TEAMS_WEBHOOK_URL: ${TEAMS_WEBHOOK_URL}
    ports: ["8080:8080"]
    volumes:
      - evidence:/evidence
      - /usr/local/bin/claude:/usr/local/bin/claude:ro   # Claude CLI from host

volumes: { pgdata: {}, evidence: {} }
```

**Bring-up:** `ADO_PAT=... TEAMS_WEBHOOK_URL=... docker compose up` — single documented command, then load the extension unpacked in Chrome.

---

## Status Lifecycle

```
RECEIVED  ──→  DRAFTED  ──→  EDITED  ──→  FILED           (happy path)
   │             │             │
   │             │             └──→  FAILED  ──→  (re-file)   ADO/Teams failed after confirm
   │             └──→  (re-generate)                          draft produced, awaiting review
   └──→  (re-generate)                                        intake only; generation not yet run / failed
```

- **RECEIVED**: written by `POST /api/evidence`. Evidence stored; generation not yet run.
- **DRAFTED**: written by `POST /api/reports/{id}/generate`. Claude CLI draft stored, awaiting human review.
- **EDITED**: written by `POST /api/reports/{id}/file` before any outbound call — the human-approved report is persisted first.
- **FILED**: terminal success. ADO Bug created with all attachments; optional Teams notification sent.
- **FAILED**: ADO/Teams step failed after confirm; `error_details` recorded; retryable by re-filing.

`DUPLICATE` is a response-only outcome flag returned by intake and is **never persisted** — a repeated `capture_id` leaves the existing row at its current state.

---

## SQL / Schema Reference

All DDL and key queries, consolidated. Applied via `db/init.sql` on first Postgres start.

### S1: Schema (`db/init.sql`)

```sql
CREATE EXTENSION IF NOT EXISTS vector;   -- pgvector on the same instance (future dedup; unused this build)

CREATE TABLE bug_reports (
    id                BIGSERIAL PRIMARY KEY,
    capture_id        UUID        NOT NULL UNIQUE,          -- idempotent intake
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status            VARCHAR(20) NOT NULL DEFAULT 'RECEIVED',
    target_url        TEXT,
    module            VARCHAR(255),
    severity          VARCHAR(20),
    priority          VARCHAR(20),
    draft_report      JSONB,
    edited_report     JSONB,
    ado_work_item_id  BIGINT,
    evidence_manifest JSONB,
    error_details     TEXT
);

CREATE INDEX idx_bug_reports_status ON bug_reports (status);
```

### S2: Idempotent Intake (EvidenceController.Intake)

```sql
INSERT INTO bug_reports (capture_id, status, target_url, evidence_manifest, created_at, updated_at)
VALUES (:captureId, 'RECEIVED', :targetUrl, :manifest, NOW(), NOW())
ON CONFLICT (capture_id) DO NOTHING
RETURNING id;
-- If no row returned, the capture already exists → respond DUPLICATE with the existing id.
```

### S3: Store Draft (ReportsController.Generate)

```sql
UPDATE bug_reports
SET draft_report = :draft, module = :module, severity = :severity, priority = :priority,
    status = 'DRAFTED', updated_at = NOW()
WHERE id = :id;
```

### S4: Persist Confirmed Edit (ReportsController.File — before outbound)

```sql
UPDATE bug_reports
SET edited_report = :edited, module = :module, severity = :severity, priority = :priority,
    status = 'EDITED', updated_at = NOW()
WHERE id = :id;
```

### S5: Mark Filed / Failed (ReportsController.File — after outbound)

```sql
-- success
UPDATE bug_reports SET ado_work_item_id = :workItemId, status = 'FILED', updated_at = NOW() WHERE id = :id;
-- failure
UPDATE bug_reports SET status = 'FAILED', error_details = :error, updated_at = NOW() WHERE id = :id;
```

### S6: Status Snapshot (monitoring)

```sql
SELECT status, COUNT(*) FROM bug_reports GROUP BY status ORDER BY status;
```

---

## Reference Documents

- [Solution.md](./solution.md)
- Project Specification — QA Copilot Browser Extension (OPE AI Initiatives)
- [Claude Code docs map](https://docs.anthropic.com/en/docs/claude-code/claude_code_docs_map.md) — headless/print mode and CLI flags
- Chrome DevTools Protocol — `Network`, `Runtime`, `Log`, `Page.captureScreenshot`
- Chrome Extensions — Manifest V3 `offscreen`, `tabCapture`, `chrome.debugger`
- Azure DevOps REST API — Work Items & attachments (api-version 7.0)
- Microsoft Teams — incoming webhooks
