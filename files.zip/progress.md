# QA Copilot — Build Progress (`progress.md`)

Single source of truth for the ralph loop. One line per `prd.md` task. The loop picks the first unchecked (`- [ ]`) task, implements it, and flips it to `- [x]` with a one-line note. Build is complete when no `- [ ]` remain (or a `STOP` file is present).

**Legend:** `- [ ]` not started · `- [x]` done (verification passed, committed)

## Phase S — Scaffolding
- [ ] T01 Monorepo + docker-compose skeleton (backend + Postgres/pgvector) + db/init.sql
- [ ] T02 Extension skeleton (Vite + crxjs, manifest.json) loads unpacked
- [ ] T03 Ralph harness scaffold (run-loop.sh, iteration-prompt.md, verify.sh)

## Phase 0 — Thin end-to-end slice
- [ ] T04 UserActionCollector — numbered repro steps + sensitive-field masking
- [ ] T05 DebuggerSession — CDP attach (Network/Runtime/Log/Page) + re-attach on nav
- [ ] T06 ConsoleNetworkCollector (console) — stack/source/line
- [ ] T07 ScreenshotCollector — viewport + full-page (captureBeyondViewport)
- [ ] T08 CaptureController + trigger — one-click local JSON evidence package (slice exit)

## Phase 1 — Full collectors + redaction
- [ ] T09 SessionCollector + NavigationLog + DomProbe
- [ ] T10 EnvironmentCollector + CookieProbe (storage/cookies/flags/roles)
- [ ] T11 Network → HAR (HarBuilder) + highlight 400/401/403/404/409/422/500
- [ ] T12 Offscreen VideoBuffer — bounded rolling 3–5 min + transfer to worker
- [ ] T13 RedactionPipeline — mask/filter/strip/PII + redaction_report, fail-closed

## Phase 1b — Intake
- [ ] T14 EvidencePackage types + UploadClient (multipart inline JSON + blobs)
- [ ] T15 Backend scaffold + data layer (Program.cs, AppDbContext, BugReport)
- [ ] T16 EvidenceController intake — idempotent + serialize console.json/environment.json

## Phase 2 — AI report + review
- [ ] T17 ILlmProvider + ClaudeCliLlmProvider + PromptTemplate + latency/spend logging
- [ ] T18 ReportsController.Generate — structured DRAFTED report + denormalized fields
- [ ] T19 ReviewScreen.tsx — editable draft + File Bug (human-in-the-loop)

## Phase 3 — Azure DevOps push
- [ ] T20 Inspect TargetDMS Bug field schema (resolve open question)
- [ ] T21 AdoRestClient — upload attachments + create Bug (JSON Patch + AttachedFile)
- [ ] T22 ReportsController.File — EDITED → FILED with all five attachments (FAILED on error)

## Phase 4 — Notify + harden
- [ ] T23 TeamsWebhookNotifier — module/severity/assigned team, best-effort
- [ ] T24 README & Architecture Doc (deliverable #6)
- [ ] T25 End-to-end rehearsal + one-command docker-compose bring-up (§C checklist)
